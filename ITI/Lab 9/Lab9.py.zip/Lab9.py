class Time:
    def __init__(self, hh=12, mm=0, s=0):
        self.hour = hh
        self.minute = mm
        self.second = s

    def setTime(self, hh=12, mm=0, s=0):
        self.hour = hh
        self.minute = mm
        self.second = s
        while self.second >= 60:
            self.second -= 60
            self.minute += 1
        while self.minute >= 60:
            self.minute -= 60
            self.hour += 1
        while self.hour > 12:
            self.hour -= 12

    def isBefore(self, t2):
        return (self.hour < t2.hour) or (self.hour == t2.hour and self.minute < t2.minute) or (self.hour == t2.hour and self.minute == t2.minute and self.second < t2.second)

    def __repr__(self):
        return (str(self.hour) + ":" + str(self.minute) + ":" + str(self.second))

    def __eq__(self, other):
        return self.hour == other.hour and self.minute == other.minute and self.second == other.second

    def duration(self, t2):
        print((str(abs(t2.hour - self.hour)) + ":" + str(abs(t2.minute - self.minute)) + ":" + str(abs(t2.second - self.second))))

###################################################################################################################
###################################################################################################################
class Car:
    def __init__(self, brand='Ford', color='Red', pilote='person', speed=0):
        self.brand = brand
        self.color = color.capitalize()
        self.pilote = pilote
        self.speed = speed
    def choice_driver(self, name):
        self.pilote = name

    def accelerate(self, flow, duration):
        if self.pilote != 'person':
            self.speed = flow * duration
        else:
            print('This car does not have a driver!')

    def display_all(self):
        print(str(self.color) + ' ' + str(self.brand) + ' driven by ' + str(self.pilote) + ', speed = ' + str(self.speed) + ' m/s.')

    def __repr__(self):
        return str(self.color) + ' ' + str(self.brand) + ' driven by ' + str(self.pilote) + ', speed = ' + str(self.speed) + ' m/s.'

    def __eq__(self, other):
        return (self.brand == other.brand) and (self.color == other.color) and (self.pilote == other.pilote) and (self.speed == other.speed)

###################################################################################################################
###################################################################################################################
class BankAccount:
    def __init__(self, name='Dupont', sold=1000):
        self.name = name
        self.price = sold

    def deposit(self, sum):
        self.price = self.price + sum

    def withdraw(self, sum):
        self.price = self.price - sum

    def display(self):
        print('The sold of the Bank account of ' + str(self.name) + ' is ' + str(self.price) + ' dollars.')


class AccountSaving(BankAccount):
    def __init__(self, name='Dupont', sold=1000, interest=0.3):
        super().__init__(name, sold)
        self.interest = interest

    def changeRate(self, value):
        self.interest = value

    def capitalisation(self, numberMonth):
        self.price = self.price * ((1 + (self.interest/100)) ** numberMonth)
        '''self.price = self.price + (self.price * (self.interest/100) * numberMonth)'''
        print('Capitalisation on ' + str(numberMonth) + ' months at the monthly rate of ' + str(self.interest) + '%.')














